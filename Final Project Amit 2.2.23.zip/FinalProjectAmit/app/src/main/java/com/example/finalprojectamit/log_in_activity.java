package com.example.finalprojectamit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class log_in_activity extends AppCompatActivity {

    ImageView exitBt;
    EditText username, password, id;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        DB = new DBHelper(this);
        username = findViewById(R.id.Username);
        password = findViewById(R.id.Password);
        id = findViewById(R.id.Id);
        exitBt = findViewById(R.id.exitBT);
        exitBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeApp(); //calling for another function
            }
        });
    }

    private void closeApp() { //exit dialog
        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Are you sure you want to exit this app?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() { // if clicking YES
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1); // exit app
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() { // if clicking NO
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                                    // nothing will happen
                    }
                }).show(); // show to dialog

        }

    public void register(View view) {
        Intent intent = new Intent(this, registaration_activity.class);
        startActivity(intent);
    }


    public void logIn(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        String id = this.id.getText().toString();

        if(TextUtils.isEmpty(user) || TextUtils.isEmpty(pass))
            Toast.makeText(log_in_activity.this, "You didn't enter your username/password/id.", Toast.LENGTH_SHORT).show();
        else {
            Boolean checkuser = DB.checkUser(user, pass, id);
            if(checkuser == true) {
                Toast.makeText(log_in_activity.this, "Log In Successful.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(log_in_activity.this, homeScreen.class);
                intent.putExtra("DBtoString()", DB.toString());
                startActivity(intent);

            }
            else
                Toast.makeText(log_in_activity.this, "Log In failed, your username/password/id is incorrect", Toast.LENGTH_SHORT).show();
        }
    }
}

