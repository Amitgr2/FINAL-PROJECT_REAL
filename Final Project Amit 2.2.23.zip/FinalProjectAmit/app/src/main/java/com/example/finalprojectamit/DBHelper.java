package com.example.finalprojectamit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "login.db";
    public static final String TABLE_NAME = "Users";
    public static final String COLUMN_USER = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_HIGHT = "hight";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PROFILEPICTURE = "profile picture";
    public static final String COLUMN_THREEPOINTSAVARAGE = "three points avarage";
    public static final String COLUMN_TWOPOINTSAVARAGE = "field points avarage";
    public static final String COLUMN_BLOCKSAVARAGE = "blocks avarage";
    public static final String COLUMN_FOULSAVARAGE = "fouls avarage";
    public static final String COLUMN_ASSISTSAVARAGE = "assists avarage";
    public static final String COLUMN_BALLSLOOSEAVARAGE = "balls loose avarage";
    public static final String COLUMN_SPEEDAVARAGE = "speed avarage";
    public static final String COLUMN_HEARTBEATAVARAGE = "heart beat avarage";

    private ByteArrayOutputStream objectByteArrayOutputStream;
    private byte[] imageToBytes;

    public DBHelper(Context context) {
        super(context, "login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users(username TEXT primary key, password TEXT, age INTEGER, hight INTEGER, id INTEGER,  threepointsavarage DOUBLE, twopointsavarage DOUBLE, blocksavarage DOUBLE, foulsavarage DOUBLE, assistsavarage DOUBLE, ballslooseavarage DOUBLE, speedavarage DOUBLE, heartbeatavarage DOUBLE, profilepicture BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
    }

    String[] allColumns = {DBHelper.COLUMN_USER, DBHelper.COLUMN_PASSWORD, DBHelper.COLUMN_AGE, DBHelper.COLUMN_HIGHT, DBHelper.COLUMN_THREEPOINTSAVARAGE, DBHelper.COLUMN_TWOPOINTSAVARAGE, DBHelper.COLUMN_BLOCKSAVARAGE, DBHelper.COLUMN_FOULSAVARAGE, DBHelper.COLUMN_ASSISTSAVARAGE, DBHelper.COLUMN_BALLSLOOSEAVARAGE, DBHelper.COLUMN_SPEEDAVARAGE, DBHelper.COLUMN_HEARTBEATAVARAGE, DBHelper.COLUMN_PROFILEPICTURE};
    //inserts data
    public boolean insertData(String username, String password, int age, int hight, int id, ModelClasss picture) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        Bitmap profilePicture = picture.getProfilePicture();
        objectByteArrayOutputStream = new ByteArrayOutputStream();
        profilePicture.compress(Bitmap.CompressFormat.JPEG,100, objectByteArrayOutputStream);
        imageToBytes = objectByteArrayOutputStream.toByteArray();


        values.put("username", username);
        Log.d("inserted","user");
        values.put("password", password);
        values.put("age", age);
        values.put("hight", hight);
        values.put("id", id);
        try {
            values.put("profilepicture", imageToBytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("inserted","IMAGE");
       /* values.put("threepointsavarage", 0);
        values.put("twopointsavarage", 0);
        values.put("blocksavarage", 0);
        Log.d("inserted","blocksavarage");

        values.put("foulsavarage", 0);
        values.put("assistsavarage", 0);
        values.put("ballslooseavarage", 0);
        values.put("speedavarage", 0);
        values.put("heartbeatavarage", 0);*/




        long result = db.insert("Users", null, values);
        if(result == -1)
            return false;
        else
            return true;
    }

    public boolean checkid(String id) { // checks if the id is already in use
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where id = ?", new String[]{String.valueOf(id)});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public boolean checkUser(String username, String password, String id) { // checks if the user info is right
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ? and id = ?", new String[]{username, password, String.valueOf(id)});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM users";
        Cursor cursor = db.rawQuery(query, null);
        return  cursor;
    }

    public Cursor getDataUser(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM users where id = ?";
        Cursor cursor = db.rawQuery(query, null);
        return  cursor;
    }
    public ArrayList<String> getAllData(int id) {
        ArrayList<String> data = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users where id = ?", null);
        if (cursor.moveToFirst()) {
            do {
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    data.add(cursor.getString(i));
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return data;
    }

}
