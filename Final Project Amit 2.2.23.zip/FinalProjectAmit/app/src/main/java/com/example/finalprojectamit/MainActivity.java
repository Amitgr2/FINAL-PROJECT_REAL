package com.example.finalprojectamit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    ImageView logo;
    Animation animation;
    Animation animation2;
    Timer timer;
    Timer timer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timer = new Timer();
        timer2 = new Timer();

        logo = findViewById(R.id.logo);
        animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
        logo.setAnimation(animation);
        //finish first animation
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                animation2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_out);
                logo.setAnimation(animation2);
            }
        }, 2500);
        timer2.schedule(new TimerTask() { // after all the animation, move to the log in frame
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, log_in_activity.class);
                startActivity(intent);
            }
        }, 5000);

    }
}