package com.example.finalprojectamit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
//import com.theartofdev.edmodo.cropper.CropImage;
//import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;
import java.io.InputStream;

public class registaration_activity extends AppCompatActivity {

    ImageView profileP, exitBt;
    Button button;
    Uri uri;
    EditText username, password, age, hight, id;
    Bitmap bitmap;
    DBHelper DB;
    boolean isCorG; // is Camera or Gallery

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registaration);

        button = findViewById(R.id.button);
        profileP = findViewById(R.id.profileP);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        age = findViewById(R.id.age);
        hight = findViewById(R.id.hight);
        id = findViewById(R.id.id);
        DB = new DBHelper(this);


        profileP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!checkStoragePermission())
                    requestStoragePermission();
                if(!checkCameraPermission())
                    requestCameraPermission();

                Dialog dialog = new Dialog(registaration_activity.this);
                dialog.setContentView(R.layout.dialog);
                dialog.setCancelable(false);

                ImageView camera = dialog.findViewById(R.id.camera);
                ImageView gallery = dialog.findViewById(R.id.gallery);

                camera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) { // when choosing the camera option
                        Intent camera = new Intent();
                        camera.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                        isCorG = true;
                        startActivityForResult(camera, 1);
                        dialog.dismiss();
                    }
                });

                gallery.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) { // when choosing the gallery option
                        Intent gallery = new Intent();
                        gallery.setType("image/*");
                        gallery.setAction(Intent.ACTION_GET_CONTENT);
                        isCorG = false;
                        startActivityForResult(Intent.createChooser(gallery, "Select Picture"), 1);
                        dialog.dismiss();
                    }
                });
                dialog.show();


            }


        });

        exitBt = findViewById(R.id.exitBT);
        exitBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeApp(); //calling for another function
            }
        });
    }


    private void requestStoragePermission() {
        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
    }

    private void requestCameraPermission() {
        requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
    }

    private boolean checkStoragePermission() {
        boolean res2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return res2;

    }

    private boolean checkCameraPermission() {
        boolean res1 = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return res1 && res2;

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

          /*  if(requestCode == 1 && resultCode == RESULT_OK) {
                Uri uri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    Picasso.with(this).load(uri).into(profileP);
                   // profileP.setImageBitmap(bitmap);

                } catch(IOException e) {
                    e.printStackTrace();
                }
            }*/
             if(requestCode == 1 && resultCode == Activity.RESULT_OK) {
                Uri uri = data.getData();
                if(isCorG == true) {
                    Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                    profileP.setImageBitmap(bitmap);
                }
                else {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                        profileP.setImageBitmap(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
               // try {

                   //Picasso.with(this).load(uri).into(profileP);
                    // profileP.setImageBitmap(bitmap);

               /* } catch(IOException e) {
                    e.printStackTrace();
                }*/
            }

        /*if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri(); //convertor for the image
               try{ // avoid crashes and image not loading
                   InputStream stream = getContentResolver().openInputStream(resultUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(stream); // converting the image to bitmap
                    profileP.setImageBitmap(bitmap);
                }catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }*/
    }

    private void closeApp() { //exit dialog
        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Are you sure you want to exit this app?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() { // if clicking YES
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1); // exit app
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() { // if clicking NO
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // nothing will happen
                    }
                }).show(); // show to dialog

    }


    public void register(View view) { // clicking the register button
        String user = username.getText().toString();
        String pass = password.getText().toString();
        int age;
        int hight;
        int id;
        ModelClasss modelClass = new ModelClasss(profileP);




            if (!username.getText().toString().isEmpty()) { // if the username field isn't empty
                if (!password.getText().toString().isEmpty()) { // if the password field isn't empty
                    if (!this.age.getText().toString().isEmpty()) { // if the age field isn't empty
                        age = Integer.parseInt(this.age.getText().toString());
                        if (!this.hight.getText().toString().isEmpty()) { // if the hight field isn't empty
                            hight = Integer.parseInt(this.hight.getText().toString());
                            if(!this.id.getText().toString().isEmpty()) { // if the id field isn't empty
                                id = Integer.parseInt(this.id.getText().toString());
                                if(DB.checkid(this.id.getText().toString()) == false) { // if the id isn't in a different user
                                    Boolean insert = DB.insertData(user, pass, age, hight, id, modelClass);
                                    if(insert == true) {
                                        Toast toast = Toast.makeText(getApplicationContext(), "The user is successfully created.", Toast.LENGTH_SHORT);
                                        toast.show();
                                        SharedPreferences sp = getSharedPreferences("MyPref", Context.MODE_PRIVATE);
                                        SharedPreferences.Editor editor = sp.edit();
                                        editor.putInt("ID", id);
                                        editor.commit();
                                        Intent intent = new Intent(this, homeScreen.class);
                                        intent.putExtra("ID", id);
                                        startActivity(intent);
                                    } else {
                                        Toast toast = Toast.makeText(getApplicationContext(), "Unable to create this user.", Toast.LENGTH_SHORT);
                                        toast.show();
                                    }
                                } else {
                                    Toast toast = Toast.makeText(getApplicationContext(), "This ID is already in use!", Toast.LENGTH_SHORT);
                                    toast.show();
                                }
                            } else {
                                Toast toast = Toast.makeText(getApplicationContext(), "You must fill up all the id field.", Toast.LENGTH_SHORT);
                                toast.show();
                            }
                        } else { // the hight field is empty
                            Toast toast = Toast.makeText(getApplicationContext(), "You must fill up all the hight field.", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    } else { // the age field is empty
                        Toast toast = Toast.makeText(getApplicationContext(), "You must fill up all the age field.", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                } else { // the password field is empty
                    Toast toast = Toast.makeText(getApplicationContext(), "You must fill up all the password field.", Toast.LENGTH_SHORT);
                    toast.show();
                }
            } else { // the username field is empty
                Toast toast = Toast.makeText(getApplicationContext(), "You must fill up the username field.", Toast.LENGTH_SHORT);
                toast.show();
            }


    }
}