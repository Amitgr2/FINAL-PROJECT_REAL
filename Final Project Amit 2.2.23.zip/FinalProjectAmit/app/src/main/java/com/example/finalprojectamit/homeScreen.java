package com.example.finalprojectamit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class homeScreen extends AppCompatActivity {

    DBHelper db;
    TextView username, id, age, hight, threeP, twoP, fouls, blocks, assists, ballsLoose, speed, heartBeat, smartWatch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        username = findViewById(R.id.usernameHomeScreen);
        id = findViewById(R.id.idHomeScreen);
        age = findViewById(R.id.ageHomeScreen);
        hight = findViewById(R.id.hightHomeScreen);
        threeP = findViewById(R.id.ThreePAvg);
        twoP = findViewById(R.id.TwoPAvg);
        fouls = findViewById(R.id.FoulAvg);
        blocks = findViewById(R.id.BlocksAvg);
        assists = findViewById(R.id.AssistsAvg);
        ballsLoose = findViewById(R.id.BallsLooseAvg);
        speed = findViewById(R.id.SpeedAvg);
        heartBeat = findViewById(R.id.HeartBeatAvg);
        smartWatch = findViewById(R.id.SmartWatchCo);

        Intent i = getIntent();
        String userID = i.getStringExtra("ID");
        id.setText(userID);

        ArrayList<String> arrayList = db.getAllData(Integer.parseInt(userID));
        for (String item : arrayList) {
            Log.d("list", "item: " + item);
        }

    }
}