package com.example.finalprojectamit;

public class User {

    private double ThreePointsAv;
    private double TwoPointsAV;
    private double HeartBitAv;
    private double SpeedAv;
    private double FoulAv;
    private double AssistsAv;
    private double BallsLooseAv;
    private double BlocksAv;
    private int Hight;
    private double age;

    public void setThreePointsAv(double threePointsAv) {
        ThreePointsAv = threePointsAv;
    }

    public void setTwoPointsAV(double twoPointsAV) {
        TwoPointsAV = twoPointsAV;
    }

    public void setHeartBitAv(double heartBitAv) {
        HeartBitAv = heartBitAv;
    }

    public void setSpeedAv(double speedAv) {
        SpeedAv = speedAv;
    }

    public void setFoulAv(double foulAv) {
        FoulAv = foulAv;
    }

    public void setAssistsAv(double assistsAv) {
        AssistsAv = assistsAv;
    }

    public void setBallsLooseAv(double ballsLooseAv) {
        BallsLooseAv = ballsLooseAv;
    }

    public void setBlocksAv(double blocksAv) {
        BlocksAv = blocksAv;
    }

    public void setHight(int hight) {
        Hight = hight;
    }

    public void setAge(double age) {
        this.age = age;
    }

    public double getThreePointsAv() {
        return ThreePointsAv;
    }

    public double getTwoPointsAV() {
        return TwoPointsAV;
    }

    public double getHeartBitAv() {
        return HeartBitAv;
    }

    public double getSpeedAv() {
        return SpeedAv;
    }

    public double getFoulAv() {
        return FoulAv;
    }

    public double getAssistsAv() {
        return AssistsAv;
    }

    public double getBallsLooseAv() {
        return BallsLooseAv;
    }

    public double getBlocksAv() {
        return BlocksAv;
    }

    public int getHight() {
        return Hight;
    }

    public double getAge() {
        return age;
    }


}
