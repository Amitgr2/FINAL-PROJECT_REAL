package com.example.finalprojectamit;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.widget.ImageView;

public class ModelClasss {
    private Bitmap profilePicture;

    public ModelClasss(ImageView profilePicture) {
        BitmapDrawable drawable = (BitmapDrawable) profilePicture.getDrawable();
        Bitmap bitmap = drawable.getBitmap();
        this.profilePicture = drawable.getBitmap();
    }

    public void setProfilePicture(Bitmap profilePicture) {
        this.profilePicture = profilePicture;
    }

    public Bitmap getProfilePicture() {
        return profilePicture;
    }

}
